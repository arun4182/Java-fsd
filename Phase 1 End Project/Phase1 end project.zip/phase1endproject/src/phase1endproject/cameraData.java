package phase1endproject;

import java.util.ArrayList; 
import java.util.List; 
import java.util.Scanner; 

@SuppressWarnings("unused")
public class cameraData {
	 private int cameraId; 
	    private String brand; 
	    private String model; 
	    private double price; 
	    private boolean available; 
	 
	    cameraData(int cameraId, String brand, String model, double price, boolean 
	available) { 
	        this.cameraId = cameraId; 
	        this.brand = brand; 
	        this.model = model; 
	        this.price = price; 
	        this.available = available; 
	    } 
	 
	    public int getCameraId() { 
	        return cameraId; 
	    } 
	 
	    public String getBrand() { 
	        return brand; 
	    } 
	 
	    public String getModel() { 
	        return model; 
	    } 
	 
	    public double getPrice() { 
	        return price; 
	    } 
	 
	    public boolean isAvailable() { 
	        return available; 
	    } 
	 
	    public void setAvailable(boolean available) { 
	        this.available = available; 
	    } 
	} 


