/**
 * 
 */
/**
 * 
 */
module linkedlist {
}