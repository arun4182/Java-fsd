/**
 * 
 */
/**
 * 
 */
module arrayRotation {
}