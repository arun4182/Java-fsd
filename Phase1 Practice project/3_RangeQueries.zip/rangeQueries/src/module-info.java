/**
 * 
 */
/**
 * 
 */
module rangeQueries {
}