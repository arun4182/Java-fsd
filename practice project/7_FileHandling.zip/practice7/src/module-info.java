/**
 * 
 */
/**
 * 
 */
module practice7 {
}