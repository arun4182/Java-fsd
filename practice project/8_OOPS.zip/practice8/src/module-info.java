/**
 * 
 */
/**
 * 
 */
module practice8 {
}