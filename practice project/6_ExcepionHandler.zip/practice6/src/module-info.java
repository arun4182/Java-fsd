/**
 * 
 */
/**
 * 
 */
module practice6 {
}