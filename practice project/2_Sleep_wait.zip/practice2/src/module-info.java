/**
 * 
 */
/**
 * 
 */
module practice2 {
}