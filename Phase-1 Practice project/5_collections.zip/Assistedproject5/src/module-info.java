/**
 * 
 */
/**
 * 
 */
module Assistedproject5 {
}