/**
 * 
 */
/**
 * 
 */
module Assistedproject4 {
}