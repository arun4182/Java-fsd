/**
 * 
 */
/**
 * 
 */
module Assistedproject2 {
}