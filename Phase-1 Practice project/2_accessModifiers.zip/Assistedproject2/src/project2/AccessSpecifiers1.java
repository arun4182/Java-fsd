package project2;

public class AccessSpecifiers1 {

	public static void main(String[] args) {
	

	}

}
