/**
 * 
 */
/**
 * 
 */
module Assistedproject8 {
}