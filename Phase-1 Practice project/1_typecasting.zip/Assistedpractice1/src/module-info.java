/**
 * 
 */
/**
 * 
 */
module Assistedpractice1 {
}