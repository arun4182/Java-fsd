package project1;
import java.util.ArrayList;
import java.util.Scanner;
public class EmailIdVerification {

	
		 public static void main(String[] args) {
		        
		        ArrayList<String> emailID = new ArrayList<String>();
		        
		        emailID.add("arun@gmail.com");
		        emailID.add("abc@cd@.com");
		        emailID.add("aaaa2@gmail.com");
		        emailID.add("bbbb@a.com");
		        emailID.add("ddddd@gmail.com");
		   
		        
		         String searchEmail = null;
		         System.out.println("Enter the email to search");
		         
		          Scanner sc = new Scanner(System.in) ;  
					System.out.println("Enter email Id : ");
		          searchEmail = sc.nextLine(); 
			
		             if(emailID.contains(searchEmail)){
		          System.out.println("email ID " + searchEmail + " found");
		      }
		      else{
		          System.out.println( "email ID " + searchEmail + " not found");
		      }
		             sc.close();
		        
		    
	

	}

}
