/**
 * 
 */
/**
 * 
 */
module Assistedproject6 {
}