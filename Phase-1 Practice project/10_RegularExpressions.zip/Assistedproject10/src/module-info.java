/**
 * 
 */
/**
 * 
 */
module Assistedproject10 {
}