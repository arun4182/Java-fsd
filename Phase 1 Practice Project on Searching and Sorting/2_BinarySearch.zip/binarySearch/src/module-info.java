/**
 * 
 */
/**
 * 
 */
module binarySearch {
}